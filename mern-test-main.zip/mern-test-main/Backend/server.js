const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const app = express();
const PORT = process.env.PORT || 5001;


app.use(bodyParser.json());

mongoose.connect('mongodb://localhost:27017/Nodejs', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
.then(() => console.log('MongoDB connected'))
.catch(err => console.error('MongoDB connection error:', err));

const ticketSchema = new mongoose.Schema({
    title: { type: String, required: true },
    description: { type: String, required: true },
    status: { type: String, default: 'Open' },
    created_at: { type: Date, default: Date.now },
    updated_at: { type: Date, default: Date.now },
});

const Ticket = mongoose.model('Ticket', ticketSchema);

app.post('/tickets', async (req, res) => {
    const { title, description } = req.body;
    const newTicket = new Ticket({ title, description });
    await newTicket.save();
    res.status(201).json(newTicket);
});

app.get('/tickets', async (req, res) => {
    const tickets = await Ticket.find();
    res.json(tickets);
});

app.get('/tickets/:id', async (req, res) => {
    const ticket = await Ticket.findById(req.params.id);
    if (!ticket) return res.status(404).send('Ticket not found');
    res.json(ticket);
});

app.put('/tickets/:id', async (req, res) => {
    const ticket = await Ticket.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!ticket) return res.status(404).send('Ticket not found');
    res.json(ticket);
});

app.delete('/tickets/:id', async (req, res) => {
    const ticket = await Ticket.findByIdAndDelete(req.params.id);
    if (!ticket) return res.status(404).send('Ticket not found');
    res.send('Ticket deleted');
});

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/Frontend/index.html');

});

app.listen(PORT, () => {

    console.log(`Server is running on http://localhost:${PORT}`);
});
